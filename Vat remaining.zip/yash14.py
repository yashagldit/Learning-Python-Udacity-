pay=input("Enter basic pay")
hra=pay*0.1
ta=pay*.05
sal=pay-hra-ta
print "HRA",hra
print "TA",ta
print "SALARY",sal
