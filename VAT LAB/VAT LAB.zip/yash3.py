num=raw_input("Enter any character :")
if(num>='A' and num<='Z'):
    print "Uppercase Character"
elif(num>='a' and num<='z'):
    print "Lowercase Character"
elif(num>='0' and num<='9'):
    print "Digit"
