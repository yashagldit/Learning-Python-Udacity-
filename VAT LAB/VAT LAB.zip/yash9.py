for i in range(1,101):
    if(i%2==0 or i%3==0):
        num=0
    else:
        print i
