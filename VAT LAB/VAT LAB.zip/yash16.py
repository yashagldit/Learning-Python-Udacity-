flag=0
while(flag==0):
    x=raw_input("Enter a string")
    if(len(x)>6):
        flag=1
        print x
