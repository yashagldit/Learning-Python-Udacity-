num1=input("Enter a Weekday no. :")
if(num1==1):
    print "Monday"
elif(num1==2):
    print "Tuesday"
elif(num1==3):
    print "Wednesday"
elif(num1==4):
    print "Thursday"
elif(num1==5):
    print "Friday"
elif(num1==6):
    print "Saturday"
elif(num1==7):
    print "Sunday"
else:
    print "Invalid Input"
