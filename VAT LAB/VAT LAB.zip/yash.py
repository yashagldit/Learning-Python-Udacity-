num1=input("Enter 1st no.")
num2=input("Enter 2nd no.")
num3=input("Enter 3rd no.")
if(num1>num2):
    if(num1>num3):
        print num1," is greater"
    else:
        print num3,"is greater"
else:
    if(num2>num3):
        print num2," is greater"
    else:
        print num3," is greater"

