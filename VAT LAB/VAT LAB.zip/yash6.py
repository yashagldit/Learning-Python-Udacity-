num=input("Enter n :")
sum=0
for i in range(1,num+1):
    sum=sum+i
print sum
