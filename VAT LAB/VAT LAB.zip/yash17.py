st=raw_input("Enter a String")
print "ZFILL",st.zfill(100)
print "STRIP",st.strip('a')
print "SPLIT",st.split('_')
