num=input("Enter n :")
sum=0
for i in range(1,11):
    print num,"*",i,"=",num*i
