num1=input("Enter any no.")
if(num1%2==0):
    print "even no."
else:
    print "odd no."
